#!/bin/bash

# Source settings file
. $HOME/.fvwm/dzen/settings

# Modify settings
Y=$((Y+70))

# Source dzen command
. $HOME/.fvwm/dzen/command

# Get mailcount Gmail
gmail() {
  count=0
  if [[ ! -n `ls ${MAILDIR}` ]]; then
    echo -n "0"
  else
    count=`ls -1 ${MAILDIR} | wc -l`
    echo -n "${count}"
  fi
}

# Get mailcount mail.com
cmail() {
  count=0
  if [[ ! -n `ls ${MAILDIR2}` ]]; then
    echo -n "0"
  else
    count=`ls -1 ${MAILDIR2} | wc -l`
    echo -n "${count}"
  fi
}

# Get pacman packages
pacman() {
  echo -n $(grep core ~/.pacmanupdates | wc -l)
  echo -n "/"
  echo -n $(grep extra ~/.pacmanupdates | wc -l)
  echo -n "/"
  echo -n $(grep community ~/.pacmanupdates | wc -l)
}

while :; do

  echo " ^fg($RED) ^ca(1,urxvt -geometry 110x30-50+50 -e mutt)\
MAIL: $(gmail)/$(cmail) ^ca()\
^fg($FG) | ^ca(1,urxvt -geometry -50+50 -e sudo packer -Syu)\
^fg($CYAN) PAC: $(pacman)   ^ca()"

  sleep $SLEEP
done | $DZEN
