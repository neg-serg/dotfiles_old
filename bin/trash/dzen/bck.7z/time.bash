#!/bin/bash

# Source settings file
. $HOME/.fvwm/dzen/settings

# Source dzen command
. $HOME/.fvwm/dzen/command

while :; do

  echo " ^fg($MAGENTA) \
$(windowname 40 | tr '[:lower:]' '[:upper:]') \
^fg($FG) | \
^fg($BLUE) $(date +%H:%M)   "

  sleep $SLEEP
done | $DZEN
