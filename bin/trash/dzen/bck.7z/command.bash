#!/bin/bash
DZEN="dzen2 -ta r -bg $BG -x $X -y $Y -h $HEIGHT -expand l -fn $FONT -dock"
